// src/App.js
import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";

import AuthProvider from "./Context/AuthContext.js";
import { useAuth } from "./Context/AuthContext.js";

// Pages
import EmployerDashboard from "./Pages/EmployerDashboard";
import PostJobForm from "./Components/PostJobForm";

import LoginPage from "./Pages/LoginPage";
import RegisterPage from "./Pages/RegisterPage";


function PrivateRoute({ children }) {
  const { user } = useAuth();
  return user ? children : <Navigate to="/login" />;
}

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<Navigate to="/login" />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/login" element={<LoginPage />} />

          {/* Employer Protected Routes */}
          <Route
            path="/employer/dashboard"
            element={
              
                <EmployerDashboard />
              
            }
          />
          <Route
            path="/employer/post-job"
            element={
              <PrivateRoute>
                <PostJobForm />
              </PrivateRoute>
            }
          />

          {/* Job Seeker Protected Routes */}
          <Route
            path="/jobseeker/dashboard"
            element={
              <PrivateRoute>
            
              </PrivateRoute>
            }
          />

          {/* Catch-all for undefined routes */}
          <Route path="*" element={<h1>404 - Page Not Found</h1>} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;