import React, { useEffect, useState } from "react";
import API_BASE_URL from "../apiConfig";

/**
 * Props:
 *  - initial: existing job DTO (for edit) or null
 *  - onSaved(): callback after save to refresh parent list
 *  - onCancel(): cancel editing
 */

export default function PostJobForm({ initial = null, onSaved = () => {}, onCancel = () => {} }) {
    const [saving, setSaving] = useState(false);
    const [form, setForm] = useState({
      EmployerId: Number(localStorage.getItem("userId")) || 0,
      Title: "",
      CompanyName: "",
      Salary: "",
      Location: "",
      Description: "",
      Codification: "",
      ApplicationInstructions: "",
      IsActive: true,
    });
    useEffect(() => {
        if (initial) {
          setForm((f) => ({
            ...f,
            EmployerId: initial.EmployerId ?? initial.employerId ?? f.EmployerId,
            Title: initial.Title ?? initial.title ?? "",
            CompanyName: initial.CompanyName ?? initial.companyName ?? "",
            Salary: initial.Salary ?? initial.salary ?? "",
            Location: initial.Location ?? initial.location ?? "",
            Description: initial.Description ?? initial.description ?? "",
            Codification: initial.Codification ?? initial.codification ?? "",
            ApplicationInstructions: initial.ApplicationInstructions ?? initial.applicationInstructions ?? "",
            IsActive: initial.IsActive ?? initial.isActive ?? true,
          }));
        }
      }, [initial]);

      function update(key, value) {
        setForm((s) => ({ ...s, [key]: value }));
      }

      const tokenHeader = () => ({ Authorization: `Bearer ${localStorage.getItem("token") || ""}` });

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        EmployerId: Number(form.EmployerId),
        Title:form.Title,
        CompanyName: String(form.CompanyName),
        Salary: form.Salary === "" ? 0 : Number(form.Salary),
        Location: form.Location,
        Description:form.Description ,
        Codification: String(form.Codification || ""),
        ApplicationInstructions: String(form.ApplicationInstructions || ""),
        IsActive:form.IsActive,
      };
      const url= initial && (initial.JobId || initial.id) ? `${API_BASE_URL}/api/Job/${initial.JobId || initial.id}` : `${API_BASE_URL}/api/Job`;
      const method = initial ? "PUT" : "POST";

      const res = await fetch(url,{
        method,
        headers:{
            "Content-type":"application/json",
            "Accept":"application/json",
            ...tokenHeader(),
        },
        body:JSON.stringify(payload),
      });

      if(!res.ok){
        throw new Error(`Server responded ${res.status}`);
      }
      onSaved();
    }
    catch(err){
        console.error("PostJobForm submit:" ,err);
        alert("Failed to save job.Check console for details");
    }
    finally{
        setSaving(false);
    }
  
  }
  return (
    <form onSubmit={handleSubmit} style={{ border: "1px solid #e6e6e6", padding: 12, borderRadius: 8 }}>
      <div style={{ display: "grid", gap: 10 }}>
        <div>
          <label>Job Title *</label>
          <input required value={form.Title} onChange={(e) => update("Title", e.target.value)} style={{ width: "100%", padding: 8 }} />
        </div>

        <div style={{ display: "flex", gap: 8 }}>
          <input placeholder="Company" value={form.CompanyName} onChange={(e) => update("CompanyName", e.target.value)} style={{ flex: 1, padding: 8 }} />
          <input placeholder="Salary" type="number" value={form.Salary} onChange={(e) => update("Salary", e.target.value)} style={{ width: 140, padding: 8 }} />
        </div>

        <div style={{ display: "flex", gap: 8 }}>
          <input placeholder="Location" value={form.Location} onChange={(e) => update("Location", e.target.value)} style={{ flex: 1, padding: 8 }} />
          <input placeholder="Codification" value={form.Codification} onChange={(e) => update("Codification", e.target.value)} style={{ width: 160, padding: 8 }} />
        </div>

        <div>
          <label>Description</label>
          <textarea value={form.Description} onChange={(e) => update("Description", e.target.value)} rows={4} style={{ width: "100%", padding: 8 }} />
        </div>

        <div>
          <label>Application Instructions</label>
          <textarea value={form.ApplicationInstructions} onChange={(e) => update("ApplicationInstructions", e.target.value)} rows={2} style={{ width: "100%", padding: 8 }} />
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <label style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <input type="checkbox" checked={form.IsActive} onChange={(e) => update("IsActive", e.target.checked)} />
            <span>Active / Published</span>
          </label>
          <div style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
            <button type="button" onClick={onCancel} style={{ padding: "8px 12px" }}>Cancel</button>
            <button type="submit" disabled={saving} style={{ padding: "8px 12px", background: "#2563eb", color: "#fff", border: "none" }}>
              {saving ? "Saving..." : initial ? "Update Job" : "Create Job"}
            </button>
          </div>
        </div>
      </div>
    </form>
  );
}