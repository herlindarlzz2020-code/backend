import React, { useState } from "react";
import API_BASE_URL from "../apiConfig";

export default function ResumeUpload({ onUploaded = () => {} }) {
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const jobSeekerId = localStorage.getItem("jobSeekerId") || localStorage.getItem("userId");

  const tokenHeader = () => ({ Authorization: `Bearer ${localStorage.getItem("token") || ""}` });

  async function handleSubmit(e) {
    e.preventDefault();
    if (!file) return alert("Select a resume file (.pdf/.doc/.docx)");
    if (!jobSeekerId) return alert("Please create a JobSeeker profile first.");

    setLoading(true);
    try {
      const fd = new FormData();
      fd.append("JobSeekerId", jobSeekerId);
      fd.append("file", file);

      await fetch(`${API_BASE_URL}/api/Resume`, {
        method: "POST",
        headers: tokenHeader(),
        body: fd,
      });

      setFile(null);
      onUploaded();
      alert("Resume uploaded");
    } catch (err) {
      console.error("Resume upload error:", err);
      alert("Upload failed");
    } finally {
      setLoading(false);
    }
  }
  return (
    <form onSubmit={handleSubmit} style={{ display: "flex", gap: 8, alignItems: "center" }}>
      <input type="file" accept=".pdf,.doc,.docx" onChange={(e) => setFile(e.target.files?.[0] || null)} />
      <button type="submit" disabled={loading} style={{ padding: "8px 12px" }}>{loading ? "Uploading..." : "Upload Resume"}</button>
    </form>
  );
}