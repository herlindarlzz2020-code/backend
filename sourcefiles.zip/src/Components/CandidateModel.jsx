import React from "react";

/**
 * candidate = { profile: {...}, resume: {...} }
 */
export default function CandidateModal({ candidate, onClose = () => {} }) {
  if (!candidate) return null;
  const profile = candidate.profile || {};
  const resume = candidate.resume || null;
  return (
    <div style={{
      position: "fixed", inset: 0, background: "rgba(0,0,0,0.4)",
      display: "grid", placeItems: "center", zIndex: 1200
    }}>
      <div style={{ width: 820, maxWidth: "96%", background: "#fff", padding: 16, borderRadius: 8 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <h3 style={{ margin: 0 }}>Candidate Profile</h3>
          <div><button onClick={onClose}>Close</button></div>
        </div>
        <div style={{ marginTop: 12, display: "grid", gap: 8 }}>
          <div><b>Name:</b> {profile.FirstName || profile.firstName || ""} {profile.LastName || profile.lastName || ""}</div>
          <div><b>Email:</b> {profile.Email || profile.email || ""}</div>
          <div><b>Phone:</b> {profile.Phone || profile.phone || ""}</div>
          {profile.Qualification && <div><b>Qualification:</b> {profile.Qualification}</div>}
          {profile.Skills && <div><b>Skills:</b> {Array.isArray(profile.Skills) ? profile.Skills.join(", ") : profile.Skills}</div>}
          {resume && (
            <div>
              <b>Resume:</b> <a href={resume.ResumePath || resume.filePath || resume.url} target="_blank" rel="noreferrer">Open</a>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
