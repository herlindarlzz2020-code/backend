const API_BASE_URL = "http://localhost:5290"

export default API_BASE_URL;