// src/pages/EmployerDashboard.jsx
import React, { useEffect, useState } from "react";
import API_BASE_URL from "../apiConfig";
import PostJobForm from "../Components/PostJobForm";
import CandidateModal from "../Components/CandidateModel";
import { useNavigate } from "react-router-dom";

export default function EmployerDashboard() {
  const navigate = useNavigate();
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [applications, setApplications] = useState([]);
  const [selectedJob, setSelectedJob] = useState(null);
  const [candidate, setCandidate] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) { navigate("/login"); return; }
    loadJobs();
    // eslint-disable-next-line
  }, []);

  function tokenHeader() {
    return { Authorization: `Bearer ${localStorage.getItem("token") || ""}` };
  }

  async function loadJobs() {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE_URL}/api/Job`,{
        method:"GET",
        headers:{
          "Accept":"application/json",
          ...tokenHeader(),
        },
      });
    if(!res.ok){
      throw new Error(`Server responded ${res.status}`);
      
    }
    const data = await res.json();
    setJobs(Array.isArray(data) ? data : data?.items || []);
  }catch(err){
    console.error("loadJobs error:",err);
    alert("failed to load jobs,Check auth or endpoint");
  }finally{
    setLoading(false);
  }
  async function handleSaved() {
    setShowForm(false);
    setEditing(null);
    await loadJobs();
  }

  async function handleEdit(job) {
    setEditing(job);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  async function handleDelete(job) {
    if (!window.confirm("Delete this job?")) return;
    try {
      const id = job.JobId || job.id;
      await fetch(`${API_BASE_URL}/api/Job/${id}`, { method: "DELETE", headers: tokenHeader() });
      await loadJobs();
    } catch (err) {
      console.error("delete job", err);
      alert("Delete failed");
    }
  }
  async function loadApplicationsFor(job) {
    try {
      const id = job.JobId || job.id;
      const res = await fetch(`${API_BASE_URL}/api/Application?jobId=${id}`, { headers: tokenHeader() });
      const data = await res.json();
      setApplications(Array.isArray(data) ? data : data?.items || []);
      setSelectedJob(job);
    } catch (err) {
      console.error("loadApplicationsFor", err);
      alert("Failed to load applications");
    }
  }

  async function viewCandidate(application) {
    try {
      const jobSeekerId = application.JobSeekerId || application.jobSeekerId || application.UserId || application.userId;
      if (!jobSeekerId) return alert("Application missing JobSeekerId");
      const pRes = await fetch(`${API_BASE_URL}/api/JobSeekers/${jobSeekerId}`, { headers: tokenHeader() });
      const profile = await pRes.json();
      const rRes = await fetch(`${API_BASE_URL}/api/Resume/jobseeker/${jobSeekerId}`, { headers: tokenHeader() }).catch(() => null);
      const resume = rRes ? await rRes.json() : null;
      setCandidate({ profile, resume });
    } catch (err) {
      console.error("viewCandidate", err);
      alert("Failed to fetch candidate details");
    }
  }
  if (loading) return <div style={{ padding: 20 }}>Loading...</div>;

  return (
    <div style={{ padding: 20, maxWidth: 1100, margin: "0 auto" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <h1 style={{ margin: 0 }}>Employer Dashboard</h1>
          <div style={{ color: "#444" }}>Create & manage job listings, review applications</div>
        </div>

        <div>
          <button onClick={() => { localStorage.removeItem("token"); navigate("/login"); }} style={{ marginRight: 8 }}>Logout</button>
          <button onClick={() => { setShowForm((s) => !s); setEditing(null); }}>{showForm ? "Cancel" : "Post Job"}</button>
        </div>
      </div>
      {showForm && <PostJobForm initial={editing} onSaved={handleSaved} onCancel={() => { setShowForm(false); setEditing(null); }} />}

<section style={{ marginTop: 18 }}>
  <h2>Your Jobs</h2>
  {jobs.length === 0 ? <div>No jobs posted yet.</div> : (
    <div style={{ display: "grid", gap: 12 }}>
      {jobs.map((job) => {
        const id = job.JobId || job.id;
        return (
          <div key={id} style={{ border: "1px solid #eee", padding: 12, borderRadius: 8, display: "flex", justifyContent: "space-between" }}>
            <div style={{ maxWidth: "70%" }}>
              <div style={{ fontWeight: 700 }}>{job.Title || job.title}</div>
              <div style={{ color: "#555" }}>{job.CompanyName || job.companyName} • {job.Location || job.location}</div>
              {job.Description && <div style={{ marginTop: 8 }}>{job.Description}</div>}
              <div style={{ marginTop: 8, color: "#666" }}>Salary: {(job.Salary ?? job.salary ?? "")}</div>
                  </div>

                  <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                    <div>
                      <button onClick={() => handleEdit(job)}>Edit</button>
                      <button onClick={() => handleDelete(job)} style={{ marginLeft: 8 }}>Delete</button>
                    </div>
                    <div>
                      <button onClick={() => loadApplicationsFor(job)}>View Applications</button>
                    </div>
                  </div>
                </div>
                  );
                })}
              </div>
            )}
          </section>
          {selectedJob && (
        <section style={{ marginTop: 20 }}>
          <h3>Applications — {selectedJob.Title || selectedJob.title}</h3>
          {applications.length === 0 ? <div>No applications yet</div> : (
            <div style={{ display: "grid", gap: 8 }}>
              {applications.map((app) => (
                <div key={app.ApplicationId || app.id} style={{ border: "1px solid #f0f0f0", padding: 10, borderRadius: 8, display: "flex", justifyContent: "space-between" }}>
                  <div>
                    <div style={{ fontWeight: 600 }}>{app.CandidateName || app.candidateName || app.JobSeekerName || `${app.JobSeekerId || app.jobSeekerId || ""}`}</div>
                    <div style={{ color: "#666" }}>{app.Status || app.status || "Applied"}</div>
                  </div>
                  <div>
                    <button onClick={() => viewCandidate(app)}>View Candidate</button>
                  </div>
                </div>
                  ))}
                  </div>
                )}
              </section>
            )}
      
            {candidate && <CandidateModal candidate={candidate} onClose={() => setCandidate(null)} />}
          </div>
        );
      }
    }