﻿/*namespace CareerLync.DTOs
{
    public class NotificationDTO
    {
        public int UserId { get; set; }
        public string Message { get; set; }
    }
}
*/